function hello(){
    alert('Tel: 00.00.00.00.00'
          'Mail: maxime.fleury78@gmail.com'
          )
}
